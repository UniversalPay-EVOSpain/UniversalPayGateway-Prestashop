<?php
global $_MODULE;
$_MODULE = array();
$_MODULE['<{kxpay}prestashop>kxpay_a39c6b5d309841ad4aeba2cfa5b42559'] = 'paga con carta';
$_MODULE['<{kxpay}prestashop>kxpay_25554a1f4911ab79c1013b41e21d188e'] = 'paga con carta';
$_MODULE['<{kxpay}prestashop>kxpay_a216e0b41b7b61d607c075a82529e077'] = 'Seleziona di nuovo il metodo di pagamento';
