<?php
global $_MODULE;
$_MODULE = array();
$_MODULE['<{kxpay}prestashop>kxpay_a39c6b5d309841ad4aeba2cfa5b42559'] = 'Pagar con tarjeta';
$_MODULE['<{kxpay}prestashop>kxpay_25554a1f4911ab79c1013b41e21d188e'] = 'Pagar con tarjeta';
$_MODULE['<{kxpay}prestashop>kxpay_a216e0b41b7b61d607c075a82529e077'] = 'Volver a seleccionar otro medio de pago';
$_MODULE['<{kxpay}prestashop>payment_25554a1f4911ab79c1013b41e21d188e'] = 'Pagar con tarjeta';
$_MODULE['<{kxpay}prestashop>kxpay_5d6448b7834599a1dbc090fd6a5ef8e3'] = 'Volver a seleccionar otro medio de pago';
$_MODULE['<{kxpay}prestashop>payment_5d6448b7834599a1dbc090fd6a5ef8e3'] = 'Volver a seleccionar otro medio de pago';
$_MODULE['<{kxpay}prestashop>kxpay_57675f3097c36f68f709004f1fb12137'] = 'Comenzar proceso de pago';
$_MODULE['<{kxpay}prestashop>payment_57675f3097c36f68f709004f1fb12137'] = 'Comenzar proceso de pago';
$_MODULE['<{kxpay}prestashop>kxpay_d1c2ac137d907de938854c7832059e4a'] = 'Pago con Sofort';
$_MODULE['<{kxpay}prestashop>payment_d1c2ac137d907de938854c7832059e4a'] = 'Pago con Sofort';
$_MODULE['<{kxpay}prestashop>kxpay_e72f191a3e8edfd87c46a739533b9802'] = 'Pago Seguro con Biocryptology';
$_MODULE['<{kxpay}prestashop>payment_e72f191a3e8edfd87c46a739533b9802'] = 'Pago Seguro con Biocryptology';
$_MODULE['<{kxpay}prestashop>kxpay_e70d64b05bc648bacee78c1a071a6662'] = 'Pago con Bizum';
$_MODULE['<{kxpay}prestashop>payment_e70d64b05bc648bacee78c1a071a6662'] = 'Pago con Bizum';
$_MODULE['<{kxpay}prestashop>kxpay_ad4d42a1e1eac99539eb06cb4bbbd516'] = 'pago con google pay';
$_MODULE['<{kxpay}prestashop>payment_ad4d42a1e1eac99539eb06cb4bbbd516'] = 'pago con google pay';
$_MODULE['<{kxpay}prestashop>kxpay_11bd01f55509aa7846e0f96e0140953f'] = 'pago con paypal';
$_MODULE['<{kxpay}prestashop>payment_11bd01f55509aa7846e0f96e0140953f'] = 'pago con paypal';
$_MODULE['<{kxpay}prestashop>kxpay_503e62fdb15f281ff53959981ce2d341'] = 'pago con amazon pay';
$_MODULE['<{kxpay}prestashop>payment_503e62fdb15f281ff53959981ce2d341'] = 'pago con amazon pay';
$_MODULE['<{kxpay}prestashop>kxpay_c180d2f439e6e33eae7068e63bbce5c6'] = 'pago con trustly';
$_MODULE['<{kxpay}prestashop>payment_c180d2f439e6e33eae7068e63bbce5c6'] = 'pago con trustly';
$_MODULE['<{kxpay}prestashop>kxpay_5b58fd98162256419e6eb5e92db4f587'] = 'pago con barzahlen';
$_MODULE['<{kxpay}prestashop>payment_5b58fd98162256419e6eb5e92db4f587'] = 'pago con barzahlen';
$_MODULE['<{kxpay}prestashop>kxpay_3cf938680bf015e5dc61f43ef65d2c29'] = 'pago en correos';
$_MODULE['<{kxpay}prestashop>payment_3cf938680bf015e5dc61f43ef65d2c29'] = 'pago en correos';
$_MODULE['<{kxpay}prestashop>kxpay_f313632e8dff7d58d9d4893dd40f3c06'] = 'existe un problema para pagar.';
$_MODULE['<{kxpay}prestashop>payment_f313632e8dff7d58d9d4893dd40f3c06'] = 'existe un problema para pagar.';
$_MODULE['<{kxpay}prestashop>kxpay_d1bd4e55018a381882940aff2218c015'] = 'contacta con nosotros';
$_MODULE['<{kxpay}prestashop>payment_d1bd4e55018a381882940aff2218c015'] = 'contacta con nosotros';


